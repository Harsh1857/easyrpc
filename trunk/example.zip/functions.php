<?php
include_once("easyrpc.php");

function saludos($nombre)
{
	return "Buen dia $nombre";
}
?>